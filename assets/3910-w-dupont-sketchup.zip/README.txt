3910 W Dupont Rd - SketchUp package
===================================

3910-w-dupont.dae  the model with colours and textures (COLLADA)
textures/          the images the model's materials use - keep this folder beside the .dae

IMPORTING

SketchUp for desktop (Pro or Studio; also Make 2017):
  1. Unzip this package; keep 3910-w-dupont.dae and the textures folder together.
  2. File > Import..., set the file type to "COLLADA File (*.dae)" and pick 3910-w-dupont.dae.
     Under Options, leave "Merge coplanar faces" on.
  3. Click to place it. It arrives as one component; right-click > Explode once to get the
     buildings, the site works and the ground as separate pieces.
  4. The ground, lawn and paving follow the terrain, so they arrive as triangles with every edge
     drawn. Open those pieces, select all, right-click > Soften/Smooth Edges - or switch edges off
     under Styles.

SketchUp for Web (needs a Go, Pro or Studio plan):
  Do not unzip. Drag this .zip onto the SketchUp for Web window, or use Import > My device (switch
  the file picker to "All files" if the .zip is greyed out). The web importer wants the .dae and
  its texture folder zipped together, which is how this package is laid out.

SketchUp Free (web) cannot import this package: the free plan only imports .skp and image files.

If the model arrives white, the textures were not found: the textures folder must sit beside the
.dae, with its name unchanged.

WHAT IS IN IT

  House: 245 parts
  Detached garage: 24 parts
  Pole barn: 20 parts
  Greenhouse: 19 parts
  Garden: 40 parts
  Site works: 49 parts
  Ground: 1 part

  398 parts, 80,804 triangles. Units are metres, Z is up.
  The origin is the address point; z = 0 is the ground at the front door.
  +Y (SketchUp's green axis) is grid north, 1.19 degrees east of true north.
  In the file every building is one group and every part a named piece inside it (roof, walls,
  each window ...); SketchUp's importer may replace those names with numbered component names.
  "Site works" is the paving, lawn, beds and fence; "Ground" is the terrain within about 12 m of
  anything built, including a strip under the drive out to the road, in plain green. Either can
  be hidden or deleted without touching the buildings. Trees, the aerial photograph and the parcel
  line are not included.

The buildings are shells - exterior surfaces only, nothing inside - and every material is opaque;
window glass is drawn as slate. This is a reconstruction for visualisation, not a survey.
